package net.gondor;

import java.util.List;

public interface ClassInterface {
	public List<TeamMembers> getTeamMembers();
	public void setTeamMembers(List<TeamMembers> teamMembers);
	public void ClassList(String name);
	public String toString();
}
