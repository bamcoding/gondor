package net.gondor;

public interface AddressInterface {
	public String toString();
}
